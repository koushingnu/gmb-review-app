# データベース設計書

## テーブル定義

### 1. google_tokens（Google認証情報）

```sql
create table public.google_tokens (
  id serial not null,
  access_token text not null,
  refresh_token text not null,
  expires_at timestamp with time zone not null,
  updated_at timestamp with time zone not null default now(),
  constraint google_tokens_pkey primary key (id)
) TABLESPACE pg_default;
```

#### カラム説明

| カラム名      | 型                       | NULL     | デフォルト | 説明                     |
| ------------- | ------------------------ | -------- | ---------- | ------------------------ |
| id            | serial                   | NOT NULL | -          | 一意識別子（PK）         |
| access_token  | text                     | NOT NULL | -          | Googleアクセストークン   |
| refresh_token | text                     | NOT NULL | -          | リフレッシュトークン     |
| expires_at    | timestamp with time zone | NOT NULL | -          | アクセストークン有効期限 |
| updated_at    | timestamp with time zone | NOT NULL | now()      | 更新日時                 |

### 2. reviews（レビュー情報）

```sql
create table public.reviews (
  review_id uuid not null,
  resource_name text not null,
  location_id text not null,
  star_rating integer not null,
  comment text,
  create_time timestamp with time zone not null,
  update_time timestamp with time zone not null,
  reviewer_display_name text not null,
  reviewer_profile_photo_url text,
  taste_score integer,
  service_score integer,
  price_score integer,
  location_score integer,
  hygiene_score integer,
  constraint reviews_pkey primary key (review_id)
) TABLESPACE pg_default;
```

#### カラム説明

| カラム名                   | 型                       | NULL     | デフォルト | 説明                          |
| -------------------------- | ------------------------ | -------- | ---------- | ----------------------------- |
| review_id                  | uuid                     | NOT NULL | -          | レビューID（PK）              |
| resource_name              | text                     | NOT NULL | -          | Googleリソース名              |
| location_id                | text                     | NOT NULL | -          | 店舗ID                        |
| star_rating                | integer                  | NOT NULL | -          | 星評価（1-5）                 |
| comment                    | text                     | NULL     | -          | レビューコメント              |
| create_time                | timestamp with time zone | NOT NULL | -          | 作成日時                      |
| update_time                | timestamp with time zone | NOT NULL | -          | 更新日時                      |
| reviewer_display_name      | text                     | NOT NULL | -          | レビュアー表示名              |
| reviewer_profile_photo_url | text                     | NULL     | -          | レビュアープロフィール画像URL |
| taste_score                | integer                  | NULL     | -          | 味の評価（0-5）               |
| service_score              | integer                  | NULL     | -          | サービスの評価（0-5）         |
| price_score                | integer                  | NULL     | -          | 価格の評価（0-5）             |
| location_score             | integer                  | NULL     | -          | 立地の評価（0-5）             |
| hygiene_score              | integer                  | NULL     | -          | 衛生の評価（0-5）             |

### 3. review_replies（返信情報）

```sql
create table public.review_replies (
  review_id uuid not null,
  comment text not null,
  update_time timestamp with time zone not null,
  sent_at timestamp with time zone,
  constraint review_replies_pkey primary key (review_id),
  constraint review_replies_review_id_fkey foreign key (review_id)
    references public.reviews(review_id) on delete cascade
) TABLESPACE pg_default;
```

#### カラム説明

| カラム名    | 型                       | NULL     | デフォルト | 説明                |
| ----------- | ------------------------ | -------- | ---------- | ------------------- |
| review_id   | uuid                     | NOT NULL | -          | レビューID（PK/FK） |
| comment     | text                     | NOT NULL | -          | 返信内容            |
| update_time | timestamp with time zone | NOT NULL | -          | 更新日時            |
| sent_at     | timestamp with time zone | NULL     | -          | Google送信日時      |

## インデックス

### reviews

```sql
CREATE INDEX idx_reviews_create_time ON public.reviews(create_time);
CREATE INDEX idx_reviews_update_time ON public.reviews(update_time);
CREATE INDEX idx_reviews_location_id ON public.reviews(location_id);
CREATE INDEX idx_reviews_star_rating ON public.reviews(star_rating);
```

### review_replies

```sql
CREATE INDEX idx_review_replies_update_time ON public.review_replies(update_time);
CREATE INDEX idx_review_replies_sent_at ON public.review_replies(sent_at);
```

### google_tokens

```sql
CREATE INDEX idx_google_tokens_updated_at ON public.google_tokens(updated_at DESC);
```

## 関数とトリガー

### 四半期スコア集計関数

```sql
CREATE OR REPLACE FUNCTION get_quarterly_scores(
  from_date timestamp,
  to_date timestamp
)
RETURNS TABLE (
  year integer,
  quarter integer,
  average_rating numeric,
  taste_avg numeric,
  service_avg numeric,
  price_avg numeric,
  location_avg numeric,
  hygiene_avg numeric,
  review_count integer
) AS $$
BEGIN
  RETURN QUERY
  WITH filtered_reviews AS (
    SELECT
      EXTRACT(YEAR FROM create_time)::integer as year,
      EXTRACT(QUARTER FROM create_time)::integer as quarter,
      star_rating,
      taste_score,
      service_score,
      price_score,
      location_score,
      hygiene_score
    FROM reviews
    WHERE create_time >= from_date
    AND create_time < to_date
  )
  SELECT
    year,
    quarter,
    ROUND(AVG(star_rating)::numeric, 1) as average_rating,
    ROUND(AVG(NULLIF(taste_score, 0))::numeric, 1) as taste_avg,
    ROUND(AVG(NULLIF(service_score, 0))::numeric, 1) as service_avg,
    ROUND(AVG(NULLIF(price_score, 0))::numeric, 1) as price_avg,
    ROUND(AVG(NULLIF(location_score, 0))::numeric, 1) as location_avg,
    ROUND(AVG(NULLIF(hygiene_score, 0))::numeric, 1) as hygiene_avg,
    COUNT(*)::integer as review_count
  FROM filtered_reviews
  GROUP BY year, quarter
  ORDER BY year, quarter;
END;
$$ LANGUAGE plpgsql;
```

### 更新日時自動更新トリガー

```sql
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.update_time = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_reviews_timestamp
  BEFORE UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_replies_timestamp
  BEFORE UPDATE ON review_replies
  FOR EACH ROW
  EXECUTE FUNCTION update_timestamp();
```

## セキュリティ設定

### RLSポリシー（推奨設定）

```sql
-- トークン情報へのアクセス制限
ALTER TABLE public.google_tokens ENABLE ROW LEVEL SECURITY;

-- 管理者のみアクセス可能なポリシー
CREATE POLICY "Admins can manage tokens" ON public.google_tokens
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (
    SELECT user_id FROM admin_users
  ));

-- レビューへのアクセス制限
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- 店舗に紐づくユーザーのみアクセス可能なポリシー
CREATE POLICY "Store users can access reviews" ON public.reviews
  FOR ALL
  TO authenticated
  USING (location_id IN (
    SELECT store_id FROM store_users WHERE user_id = auth.uid()
  ));
```

## バックアップ戦略

1. 定期バックアップ

   - 日次完全バックアップ
   - 1時間ごとのWALアーカイブ
   - 7日間のバックアップ保持

2. リストア手順
   - 完全バックアップからのリストア
   - WALリプレイによるポイントインタイムリカバリ
   - データ整合性の検証

## 運用管理

1. パフォーマンスモニタリング

   - クエリ実行時間の監視
   - インデックス使用状況の確認
   - テーブルサイズの監視

2. メンテナンス

   - 定期的なVACUUM
   - 統計情報の更新
   - インデックスの再構築

3. セキュリティ
   - アクセスログの監視
   - 権限設定の定期レビュー
   - セキュリティパッチの適用
